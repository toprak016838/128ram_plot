#!/bin/bash

sudo apt install -y libsodium-dev libgmp3-dev cmake g++ git

git clone https://github.com/madMAx43v3r/chia-plotter.git 

cd chia-plotter

git submodule update --init

./make_devel.sh

cd build
mkdir /root/temp
mkdir /root/plt
chmod +x /root/temp
chmod +x /root/plt


./chia_plot -n -1 -r 32 -u 256 -t /root/temp/ -2 /mnt/ramdisk/ -d /root/plt/ -c xch1yk0cdkg4yxsqa2z9jwuu9a7h62stxa9qwfyrpeqzp6xmg9cm6g9qt40jfu -f 81643818cc5cfe83e07252a3d752b463508375dfa128631a2713c4254c885d201239f504b9b60c5990f6f93bf8292498
